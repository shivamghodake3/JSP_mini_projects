package jsp_final;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DisplayBook")
public class DisplayBook extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int bid=Integer.parseInt(req.getParameter("bookid"));
		String bname=req.getParameter("bname");
		int price=Integer.parseInt(req.getParameter("bprice"));
		String author=req.getParameter("author");
		int yop=Integer.parseInt((req.getParameter("yop")));
		
		PrintWriter pw=resp.getWriter();
		pw.print("<html><body>");
		pw.print("Book id: "+bid+"<br><br>");
		pw.print("Book Name: "+bname+"<br><br>");
		pw.print("Book Price: "+price+"<br><br>");
		pw.print("Book author: "+author+"<br><br>");
		pw.print("Book Year of Production: "+yop+"<br><br>");
		pw.print("<h1>"+"Book Added Successfully In Database."+"</h1>");
		pw.print("</body></html>");
	}
}
